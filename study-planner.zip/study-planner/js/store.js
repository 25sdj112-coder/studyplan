/* 저장소: 브라우저 localStorage에 기록을 저장해요. (서버 없이 동작)
 * 처음 열면 data/seed.js 의 기본 데이터를 불러오고, 그 뒤로는 이 브라우저에 저장된 값을 써요.
 * app.js 는 Firestore 와 비슷한 모양의 db.collection(이름).onSnapshot / db.doc('컬렉션/id').update 만 알면 돼요. */
(function () {
  'use strict';
  var KEY = 'study-planner-data-v1';
  var data = {};
  var ok = true;
  var subs = [];

  function clone(x) { return JSON.parse(JSON.stringify(x)); }
  function seed() { return clone(window.PLANNER_SEED || {}); }

  function load() {
    try {
      var raw = localStorage.getItem(KEY);
      if (raw) { data = JSON.parse(raw); return; }
    } catch (e) { ok = false; }
    data = seed();
    save();
  }
  function save() {
    try { localStorage.setItem(KEY, JSON.stringify(data)); } catch (e) { ok = false; }
  }
  function notify() { subs.slice().forEach(function (f) { f(); }); }
  function commit() { save(); notify(); }

  function split(path) {
    var i = path.indexOf('/');
    return [path.slice(0, i), path.slice(i + 1)];
  }
  function docRef(col, id) {
    return {
      get id() { return id; },
      onSnapshot: function (cb) {
        function fire() {
          var d = data[col] && data[col][id];
          cb({ exists: !!d, id: id, data: function () { return d ? clone(d) : undefined; } });
        }
        subs.push(fire); setTimeout(fire, 0);
        return function () { subs = subs.filter(function (f) { return f !== fire; }); };
      },
      set: function (obj) {
        (data[col] = data[col] || {})[id] = clone(obj); commit(); return Promise.resolve();
      },
      update: function (obj) {
        if (!data[col] || !data[col][id]) return Promise.reject({ code: 'not_found' });
        Object.assign(data[col][id], clone(obj)); commit(); return Promise.resolve();
      },
      delete: function () {
        if (data[col]) delete data[col][id]; commit(); return Promise.resolve();
      }
    };
  }
  function colRef(col) {
    return {
      doc: function (id) { return docRef(col, id); },
      onSnapshot: function (cb) {
        function fire() {
          var c = data[col] || {};
          cb({ docs: Object.keys(c).map(function (id) {
            return { id: id, data: function () { return clone(c[id]); } };
          }) });
        }
        subs.push(fire); setTimeout(fire, 0);
        return function () { subs = subs.filter(function (f) { return f !== fire; }); };
      }
    };
  }

  load();

  window.PlannerStore = {
    db: {
      collection: colRef,
      doc: function (path) { var p = split(path); return docRef(p[0], p[1]); }
    },
    persistent: function () { return ok; },
    exportJSON: function () { return JSON.stringify({ app: 'study-planner', version: 1, data: data }, null, 2); },
    importJSON: function (text) {
      var obj = JSON.parse(text);
      var d = obj && obj.app === 'study-planner' ? obj.data : null;
      if (!d || typeof d !== 'object') throw new Error('bad file');
      data = d; commit();
    },
    reset: function () { data = seed(); commit(); }
  };
})();
