(function () {
  'use strict';
  var SUBJECTS = ['수학', '국어', '영어', '한국사', '통합과학', '사회탐구', '지구시스템과학', '일본어'];
  var DAYS = ['일', '월', '화', '수', '목', '금', '토'];
  var WEEK = ['월', '화', '수', '목', '금', '토', '일'];
  var state = {
    tab: 'today', db: undefined, readOnly: false,
    tasks: [], grades: [], plan: [], mocks: [], sched: [], coach: null, method: null,
    loaded: {}, open: {}
  };
  var busy = {};
  var pending = false;
  var toastTimer = null;
  var view = document.getElementById('view');

  try { var saved = localStorage.getItem('planner-tab'); if (saved && /^(today|week|grades|mock)$/.test(saved)) state.tab = saved; } catch (e) {}

  function esc(v) {
    return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function num(v, d) { var n = Number(v); return isFinite(n) ? n : (d || 0); }
  function pad(n) { return n < 10 ? '0' + n : '' + n; }
  function keyOf(d) { return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); }
  function parseKey(k) { var p = String(k).split('-'); return new Date(num(p[0]), num(p[1]) - 1, num(p[2])); }
  function fmtShort(k) { var d = parseKey(k); return (d.getMonth() + 1) + '/' + d.getDate() + '(' + DAYS[d.getDay()] + ')'; }
  function subjIdx(s) {
    var i = SUBJECTS.indexOf(s);
    if (i >= 0) return (i % 8) + 1;
    var h = 0, str = String(s);
    for (var j = 0; j < str.length; j++) h = (h * 31 + str.charCodeAt(j)) >>> 0;
    return (h % 8) + 1;
  }
  function chip(s) { return '<span class="chip" style="--c:var(--s' + subjIdx(s) + ')"><i></i>' + esc(s) + '</span>'; }
  function byOrder(a, b) {
    return (num(a.order, 999) - num(b.order, 999)) || String(a.title || '').localeCompare(String(b.title || ''));
  }
  function byNum(a, b) { return num(a.order, 999) - num(b.order, 999); }
  function toast(msg) {
    var el = document.getElementById('toast');
    el.textContent = msg; el.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { el.hidden = true; }, 3200);
  }

  /* ---------- 저장소 ---------- */
  function docs(snap) {
    return snap.docs.map(function (d) { return Object.assign({ id: d.id }, d.data()); });
  }
  function start(db) {
    state.db = db;
    if (!db) { render(); return; }
    function sub(name, key) {
      db.collection(name).onSnapshot(function (snap) {
        state[key] = docs(snap); state.loaded[key] = true; schedule();
      }, function () { state.loaded[key] = true; schedule(); });
    }
    function one(path, key) {
      db.doc(path).onSnapshot(function (s) {
        state[key] = s.exists ? s.data() : null; state.loaded[key] = true; schedule();
      }, function () { state.loaded[key] = true; schedule(); });
    }
    sub('tasks', 'tasks'); sub('grades', 'grades'); sub('plan', 'plan'); sub('mocks', 'mocks'); sub('schedule', 'sched');
    one('notes/coach', 'coach'); one('notes/method', 'method');
    render();
  }
  function write(key, ref, data) {
    if (busy[key]) { schedule(); return; }
    busy[key] = true;
    ref.update(data).then(function () { busy[key] = false; }, function (e) {
      busy[key] = false;
      if (e && e.code === 'invalid_argument') {
        state.readOnly = true; toast('이 계정에서는 기록을 바꿀 수 없어요. 보기만 가능해요.');
      } else { toast('저장하지 못했어요. 다시 눌러 주세요.'); }
      schedule();
    });
  }
  function toggleTask(id, checked) {
    if (!state.db) return;
    write('tasks/' + id, state.db.collection('tasks').doc(id), { done: !!checked });
  }
  function toggleSupp(mid, idx, checked) {
    if (!state.db) return;
    var m = state.mocks.filter(function (x) { return x.id === mid; })[0];
    if (!m || !Array.isArray(m.supplement)) return;
    var arr = m.supplement.map(function (s, i) { return i === idx ? Object.assign({}, s, { done: !!checked }) : s; });
    write('mocks/' + mid, state.db.collection('mocks').doc(mid), { supplement: arr });
  }

  /* ---------- 화면 조각 ---------- */
  function notReady(key) { return state.db !== null && !state.loaded[key]; }
  function emptyCard(title, text) {
    return '<section class="card empty"><strong>' + esc(title) + '</strong><p>' + esc(text) + '</p></section>';
  }
  function loadingCard() { return '<section class="card empty"><p>불러오는 중…</p></section>'; }
  function taskRow(t, showDate) {
    var dis = state.readOnly ? ' disabled' : '';
    var id = 't-' + esc(t.id);
    return '<li class="row"><label class="task" for="' + id + '"><input type="checkbox" id="' + id + '" data-task="' + esc(t.id) + '"' +
      (t.done ? ' checked' : '') + dis + '><span class="box"></span><span class="tmain"><span class="ttitle">' + esc(t.title) +
      '</span><span class="tsub">' + chip(t.subject || '기타') +
      (num(t.minutes) ? '<span class="mono">' + num(t.minutes) + '분</span>' : '') +
      (showDate ? '<span class="tag late">' + esc(fmtShort(t.date)) + ' 못 한 것</span>' : '') +
      (t.example ? '<span class="tag">예시</span>' : '') + '</span></span></label><button type="button" class="del" data-del="' + esc(t.id) + '" aria-label="이 할 일 지우기">✕</button></li>';
  }

  function viewToday() {
    if (notReady('tasks')) return loadingCard();
    var today = keyOf(new Date());
    var list = state.tasks.filter(function (t) { return t.date === today; }).sort(byOrder);
    var late = state.tasks.filter(function (t) { return t.date && t.date < today && !t.done; })
      .sort(function (a, b) { return a.date < b.date ? -1 : a.date > b.date ? 1 : byOrder(a, b); });
    var out = '';
    if (state.coach && state.coach.text) {
      out += '<section class="card coach"><span class="who">CLAUDE 메모' + (state.coach.date ? ' · ' + esc(fmtShort(state.coach.date)) : '') +
        '</span><p>' + esc(state.coach.text) + '</p></section>';
    }
    if (!list.length) {
      out += emptyCard('오늘 계획이 아직 없어요', '오늘 한 일이나 할 일을 Claude에게 말하면 이 화면에 정리돼요.');
    } else {
      var done = list.filter(function (t) { return t.done; }).length;
      var pm = 0, dm = 0;
      list.forEach(function (t) { pm += num(t.minutes); if (t.done) dm += num(t.minutes); });
      var pct = Math.round(done / list.length * 100);
      out += '<section class="card hero"><div class="hero-nums"><span class="big mono">' + done + '</span><span class="of mono">/ ' + list.length +
        '</span><span class="lbl">완료</span></div><div class="bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="' + pct +
        '"><i style="width:' + pct + '%"></i></div><div class="hero-meta"><span class="mono">' + dm + ' / ' + pm + '분</span><span class="mono">' + pct + '%</span></div></section>';
      out += '<section class="card"><h2 class="sec-h">오늘 할 일</h2><ul class="list">' + list.map(function (t) { return taskRow(t, false); }).join('') + '</ul></section>';
    }
    if (late.length) {
      out += '<section class="card"><h2 class="sec-h">밀린 항목 <small>' + late.length + '개</small></h2><ul class="list">' +
        late.map(function (t) { return taskRow(t, true); }).join('') + '</ul></section>';
    }
    return out;
  }

  function weekDays() {
    var t = new Date(); t.setHours(0, 0, 0, 0);
    var s = new Date(t); s.setDate(t.getDate() - ((t.getDay() + 6) % 7));
    var out = [];
    for (var i = 0; i < 7; i++) { var d = new Date(s); d.setDate(s.getDate() + i); out.push(d); }
    return out;
  }
  function schedCard() {
    if (!state.sched.length) return '';
    var todayW = WEEK[(new Date().getDay() + 6) % 7];
    return '<section class="card"><h2 class="sec-h">주간 시간표 <small>학교 8–17시 기준</small></h2><ul class="list">' +
      state.sched.slice().sort(byNum).map(function (r) {
        return '<li class="sched' + (r.day === todayW ? ' now' : '') + '"><span class="dl">' + esc(r.day) + '</span><span class="dt">' + esc(r.text) + '</span></li>';
      }).join('') + '</ul></section>';
  }
  function viewWeek() {
    if (notReady('tasks')) return loadingCard();
    var days = weekDays(), today = keyOf(new Date());
    var keys = days.map(keyOf);
    var wk = state.tasks.filter(function (t) { return keys.indexOf(t.date) >= 0; });
    var head = fmtShort(keys[0]) + ' – ' + fmtShort(keys[6]);
    if (!wk.length) {
      return schedCard() + emptyCard('이번 주 기록이 아직 없어요', '하루 한 번 한 일을 Claude에게 말하면 요일별 달성률과 과목별 공부 시간이 여기에 쌓여요.');
    }
    var wdone = wk.filter(function (t) { return t.done; }).length;
    var wrate = Math.round(wdone / wk.length * 100);
    var L = 34, R = 336, T = 14, B = 118, step = (R - L) / 7, bw = 24;
    function y(p) { return B - (B - T) * p / 100; }
    var svg = '<svg class="chart" viewBox="0 0 340 146" role="img" aria-label="요일별 달성률 막대 그래프">';
    [0, 50, 100].forEach(function (p) {
      svg += '<line class="gl" x1="' + L + '" x2="' + R + '" y1="' + y(p) + '" y2="' + y(p) + '"/>' +
        '<text class="ax" x="' + (L - 6) + '" y="' + (y(p) + 3.5) + '" text-anchor="end">' + p + '</text>';
    });
    keys.forEach(function (k, i) {
      var ts = wk.filter(function (t) { return t.date === k; });
      var cx = L + i * step + step / 2, isT = k === today;
      if (ts.length) {
        var rate = Math.round(ts.filter(function (t) { return t.done; }).length / ts.length * 100);
        var h = Math.max(2, (B - T) * rate / 100);
        svg += '<rect class="' + (isT ? 'bt' : 'bd') + '" x="' + (cx - bw / 2) + '" y="' + (B - h) + '" width="' + bw + '" height="' + h + '" rx="3"/>' +
          '<text class="ax val" x="' + cx + '" y="' + (B - h - 5) + '" text-anchor="middle">' + rate + '</text>';
      } else {
        svg += '<text class="ax" x="' + cx + '" y="' + (B - 5) + '" text-anchor="middle">–</text>';
      }
      svg += '<text class="ax' + (isT ? ' now' : '') + '" x="' + cx + '" y="136" text-anchor="middle">' + WEEK[i] + '</text>';
    });
    svg += '</svg>';
    var subj = {}, max = 0;
    wk.forEach(function (t) {
      var s = t.subject || '기타';
      subj[s] = subj[s] || { p: 0, d: 0 };
      subj[s].p += num(t.minutes); if (t.done) subj[s].d += num(t.minutes);
    });
    var names = Object.keys(subj).sort(function (a, b) { return subj[b].p - subj[a].p; });
    names.forEach(function (s) { if (subj[s].p > max) max = subj[s].p; });
    var rows = names.map(function (s) {
      var p = subj[s].p, d = subj[s].d;
      var w = max ? Math.round(p / max * 100) : 0;
      var f = p ? Math.round(d / p * 100) : 0;
      return '<div class="srow">' + chip(s) + '<div class="track" style="width:' + w + '%"><i style="width:' + f + '%"></i></div><span class="val mono">' + d + ' / ' + p + '분</span></div>';
    }).join('');
    return schedCard() +
      '<section class="card"><h2 class="sec-h">주간 달성률 <small class="mono">' + esc(head) + '</small></h2>' +
      '<p class="sub">이번 주 전체 <b class="mono">' + wdone + ' / ' + wk.length + '</b>개 완료 · <b class="mono">' + wrate + '%</b>. 막대는 요일별 완료 비율(%)이에요.</p>' + svg + '</section>' +
      '<section class="card"><h2 class="sec-h">과목별 공부 시간</h2><p class="sub">진한 부분이 끝낸 시간, 전체 길이가 계획한 시간이에요.</p>' + rows + '</section>';
  }

  function viewGrades() {
    if (notReady('grades')) return loadingCard();
    var out = '';
    var gs = state.grades.slice().sort(function (a, b) { return (num(b.grade) - num(a.grade)) || String(a.subject).localeCompare(String(b.subject)); });
    if (!gs.length) {
      out += emptyCard('등급이 아직 없어요', '과목별 내신·모의고사 등급을 Claude에게 알려 주면 약한 과목 순서로 정리돼요.');
    } else {
      out += '<section class="card"><h2 class="sec-h">과목별 등급 <small>낮은 등급부터</small></h2><p class="sub">1등급이 가장 높아요.</p><ul class="list">' +
        gs.map(function (g) {
          var n = Math.min(9, Math.max(1, Math.round(num(g.grade, 1))));
          var cells = '';
          for (var i = 1; i <= 9; i++) cells += '<span' + (i === n ? ' class="on"' : '') + '>' + i + '</span>';
          return '<li class="grade"><div class="g-top">' + chip(g.subject || '기타') +
            '<span class="g-meta">' + esc(g.kind || '') + (g.asOf ? ' · ' + esc(g.asOf) : '') + '</span></div>' +
            '<div class="g-row"><span class="g-num mono">' + n + '<small>등급</small></span><div class="scale" aria-hidden="true">' + cells + '</div></div></li>';
        }).join('') + '</ul></section>';
    }
    if (notReady('plan')) return out + loadingCard();
    var pl = state.plan.slice().sort(byOrder);
    if (!pl.length) {
      out += emptyCard('하루 공부 계획이 아직 없어요', '등급을 알려 주면 그 등급에 맞춘 하루 과목별 공부 시간이 여기에 올라와요.');
    } else {
      var tot = 0; pl.forEach(function (p) { tot += num(p.minutes); });
      out += '<section class="card"><h2 class="sec-h">평일 하루 기본 계획</h2><ul class="list">' +
        pl.map(function (p) {
          return '<li class="prow">' + chip(p.subject || '기타') + '<span class="focus">' + esc(p.focus || '') + '</span><span class="min mono">' + num(p.minutes) + '분</span></li>';
        }).join('') + '</ul><div class="ptotal"><span>하루 합계</span><span class="mono">' + tot + '분 (' + (Math.round(tot / 6) / 10) + '시간)</span></div></section>';
    }
    return out;
  }

  function methodCard() {
    var m = state.method;
    if (!m || !Array.isArray(m.steps) || !m.steps.length) return '';
    var isOpen = state.open.__method === undefined ? true : state.open.__method;
    return '<details class="mock method" data-mock="__method"' + (isOpen ? ' open' : '') + '><summary><span><span class="m-title">' + esc(m.title || '오답정리 방법') +
      '</span><br><span class="m-sub">' + esc(m.sub || '') + '</span></span></summary><div class="m-body"><ol class="steps">' +
      m.steps.map(function (s) { return '<li><div><b>' + esc(s.t) + '</b><span>' + esc(s.d) + '</span></div></li>'; }).join('') +
      '</ol>' + (m.tip ? '<div class="note">' + esc(m.tip) + '</div>' : '') + '</div></details>';
  }
  function nosHtml(arr) {
    return '<div class="nos">' + arr.map(function (n) { return '<span class="no">' + esc(n) + '</span>'; }).join('') + '</div>';
  }
  function viewMock() {
    if (notReady('mocks')) return loadingCard();
    var out = methodCard();
    if (!state.mocks.length) {
      return out + emptyCard('모의고사 분석이 아직 없어요', '시험 정보(몇 년 몇 월, 과목)와 맞은 번호·틀린 번호를 Claude에게 알려 주세요. 틀린 유형 분석과 보충 계획이 여기에 쌓여요.');
    }
    var ms = state.mocks.slice().sort(function (a, b) {
      return String(b.date || '').localeCompare(String(a.date || '')) || byNum(a, b);
    });
    return out + ms.map(function (m, idx) {
      var hasWrong = Array.isArray(m.wrong);
      var wrong = hasWrong ? m.wrong : [];
      var total = num(m.total);
      var types = Array.isArray(m.types) ? m.types : [];
      var supp = Array.isArray(m.supplement) ? m.supplement : [];
      var prio = Array.isArray(m.priority) ? m.priority : [];
      var bd = Array.isArray(m.breakdown) ? m.breakdown : [];
      var tmax = 0; types.forEach(function (t) { if (num(t.count) > tmax) tmax = num(t.count); });
      var isOpen = state.open[m.id] === undefined ? idx === 0 : state.open[m.id];
      var body = '<div class="m-score">' +
        (m.score != null ? '<div><b class="mono">' + num(m.score) + '</b><span>점수</span></div>' : '') +
        (m.grade != null ? '<div><b class="mono">' + num(m.grade) + '</b><span>등급</span></div>' : '') +
        (total && hasWrong ? '<div><b class="mono">' + (total - wrong.length) + ' / ' + total + '</b><span>맞은 문제</span></div>' : '') +
        '<div><b class="mono">' + (hasWrong ? wrong.length : '–') + '</b><span>틀린 문제</span></div></div>';
      if (m.note) body += '<p class="m-note">' + esc(m.note) + '</p>';
      if (bd.length) {
        body += '<div><h3 class="h3">영역별 득점</h3>' + bd.map(function (b) {
          var p = num(b.max) ? Math.round(num(b.got) / num(b.max) * 100) : 0;
          return '<div class="trow ok"><span class="tn">' + esc(b.name) + '</span><span class="mono">' + num(b.got) + ' / ' + num(b.max) +
            '</span><div class="track"><i style="width:' + p + '%"></i></div></div>';
        }).join('') + '</div>';
      }
      body += '<div><h3 class="h3">틀린 번호</h3>' + (wrong.length ? nosHtml(wrong) : '<span class="m-sub">' + (hasWrong ? '없음' : '틀린 번호를 알려주면 채워져요') + '</span>') + '</div>';
      if (prio.length) {
        body += '<div><h3 class="h3">풀이 순서</h3>' + prio.map(function (p) {
          return '<div class="prio"><div class="prio-h">' + esc(p.label) + '</div>' + nosHtml(Array.isArray(p.nos) ? p.nos : []) +
            (p.why ? '<div class="m-sub">' + esc(p.why) + '</div>' : '') + '</div>';
        }).join('') + '</div>';
      }
      if (types.length) {
        body += '<div><h3 class="h3">틀린 유형</h3>' + types.map(function (t) {
          var w = tmax ? Math.round(num(t.count) / tmax * 100) : 0;
          return '<div class="trow"><span class="tn">' + esc(t.name) + (t.cause ? ' <span class="cause">· ' + esc(t.cause) + '</span>' : '') +
            '</span><span class="mono">' + num(t.count) + '개</span><div class="track"><i style="width:' + w + '%"></i></div></div>';
        }).join('') + '</div>';
      }
      if (supp.length) {
        body += '<div><h3 class="h3">보충 계획</h3><ul class="list">' + supp.map(function (s, i) {
          var id = 's-' + esc(m.id) + '-' + i;
          return '<li><label class="task" for="' + id + '"><input type="checkbox" id="' + id + '" data-supp="' + esc(m.id) + ':' + i + '"' + (s.done ? ' checked' : '') + (state.readOnly ? ' disabled' : '') +
            '><span class="box"></span><span class="tmain"><span class="ttitle">' + esc(s.title) + '</span></span></label></li>';
        }).join('') + '</ul></div>';
      }
      return '<details class="mock" data-mock="' + esc(m.id) + '"' + (isOpen ? ' open' : '') + '><summary><span><span class="m-title">' + esc(m.label || '모의고사') +
        '</span><br><span class="m-sub">' + esc([m.subject, m.date].filter(Boolean).join(' · ')) + '</span></span></summary><div class="m-body">' + body + '</div></details>';
    }).join('');
  }

  /* ---------- 렌더 ---------- */
  function render() {
    var ae = document.activeElement, aid = ae && ae.id;
    var now = new Date();
    document.getElementById('today-label').textContent =
      now.getFullYear() + '년 ' + (now.getMonth() + 1) + '월 ' + now.getDate() + '일 ' + DAYS[now.getDay()] + '요일';
    ['today', 'week', 'grades', 'mock'].forEach(function (t) {
      var b = document.getElementById('tab-' + t);
      b.setAttribute('aria-selected', t === state.tab ? 'true' : 'false');
      b.tabIndex = t === state.tab ? 0 : -1;
    });
    var html = '';
    if (state.db === null) {
      html += '<div class="note warn">저장소를 불러오지 못했어요. 페이지를 새로고침해 주세요.</div>';
    } else if (window.PlannerStore && !window.PlannerStore.persistent()) {
      html += '<div class="note warn">이 브라우저에서는 기록이 저장되지 않아요. 시크릿 모드라면 일반 창에서 열어 주세요.</div>';
    } else if (state.readOnly) {
      html += '<div class="note">보기 전용이에요. 체크는 저장되지 않아요.</div>';
    }
    if (state.tab === 'today') html += viewToday();
    else if (state.tab === 'week') html += viewWeek();
    else if (state.tab === 'grades') html += viewGrades();
    else html += viewMock();
    view.innerHTML = html;
    document.getElementById('addbox').hidden = state.tab !== 'today';
    if (aid) {
      var el = document.getElementById(aid);
      if (el && el !== document.activeElement && el.focus) el.focus({ preventScroll: true });
    }
  }
  function schedule() {
    if (pending) return;
    pending = true;
    requestAnimationFrame(function () { pending = false; render(); });
  }

  document.querySelector('.tabs').addEventListener('click', function (e) {
    var b = e.target.closest('[data-tab]');
    if (!b) return;
    state.tab = b.getAttribute('data-tab');
    try { localStorage.setItem('planner-tab', state.tab); } catch (err) {}
    render();
  });
  view.addEventListener('change', function (e) {
    var t = e.target;
    if (t.matches('[data-task]')) toggleTask(t.getAttribute('data-task'), t.checked);
    else if (t.matches('[data-supp]')) {
      var p = t.getAttribute('data-supp'), i = p.lastIndexOf(':');
      toggleSupp(p.slice(0, i), num(p.slice(i + 1)), t.checked);
    }
  });
  view.addEventListener('toggle', function (e) {
    var d = e.target;
    if (d && d.matches && d.matches('details[data-mock]')) state.open[d.getAttribute('data-mock')] = d.open;
  }, true);

  render();
  /* ---------- 할 일 추가·삭제, 백업 ---------- */
  function initExtras() {
    var form = document.getElementById('addform');
    var sel = document.getElementById('add-subject');
    sel.innerHTML = SUBJECTS.concat(['기타']).map(function (s) { return '<option>' + esc(s) + '</option>'; }).join('');
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var title = form.elements.title.value.trim();
      if (!title || !state.db) return;
      var id = 'u' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5);
      var today = keyOf(new Date());
      var order = state.tasks.filter(function (t) { return t.date === today; })
        .reduce(function (m, t) { return Math.max(m, num(t.order)); }, 0) + 1;
      state.db.collection('tasks').doc(id).set({
        date: today, order: order, subject: form.elements.subject.value,
        minutes: Math.max(0, Math.round(num(form.elements.minutes.value))), done: false, title: title
      }).then(function () { form.elements.title.value = ''; toast('추가했어요.'); },
              function () { toast('저장하지 못했어요.'); });
    });
    view.addEventListener('click', function (e) {
      var b = e.target.closest('[data-del]');
      if (!b || !state.db) return;
      if (!window.confirm('이 할 일을 지울까요?')) return;
      state.db.collection('tasks').doc(b.getAttribute('data-del')).delete();
    });
    document.getElementById('btn-export').addEventListener('click', function () {
      if (!window.PlannerStore) return;
      var blob = new Blob([window.PlannerStore.exportJSON()], { type: 'application/json' });
      var a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = 'planner-backup-' + keyOf(new Date()) + '.json';
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(function () { URL.revokeObjectURL(a.href); }, 1000);
      toast('백업 파일을 내려받았어요.');
    });
    var file = document.getElementById('file-import');
    document.getElementById('btn-import').addEventListener('click', function () { file.click(); });
    file.addEventListener('change', function () {
      var f = file.files && file.files[0];
      if (!f || !window.PlannerStore) return;
      var r = new FileReader();
      r.onload = function () {
        try { window.PlannerStore.importJSON(String(r.result)); toast('가져왔어요.'); }
        catch (err) { toast('파일 형식이 맞지 않아요.'); }
        file.value = '';
      };
      r.readAsText(f);
    });
    document.getElementById('btn-reset').addEventListener('click', function () {
      if (!window.PlannerStore) return;
      if (window.confirm('처음 상태로 되돌릴까요? 지금까지의 기록이 사라져요.')) { window.PlannerStore.reset(); toast('처음 상태로 되돌렸어요.'); }
    });
  }

  initExtras();
  start(window.PlannerStore ? window.PlannerStore.db : null);
})();
